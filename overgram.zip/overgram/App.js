
import React, { useState } from 'react';
import {
  View, Text, TextInput, ScrollView,
  TouchableOpacity, StyleSheet, StatusBar
} from 'react-native';

export default function App() {
  const [page, setPage] = useState('Чати');
  const [selectedChat, setSelectedChat] = useState(null);
  const [search, setSearch] = useState('');
  const [draft, setDraft] = useState('');
  const [dark, setDark] = useState(true);
  const [balance, setBalance] = useState(1000);

  const [chats, setChats] = useState([
    { id: 1, name: 'Олександр', avatar: '👨🏻', preview: 'Привіт! Як справи?', time: '16:45', messages: [] },
    { id: 2, name: 'Софія', avatar: '🌸', preview: 'Надіслала подарунок ⭐', time: '15:32', messages: [] },
    { id: 3, name: 'Максим', avatar: '🦊', preview: 'Побачимось завтра', time: '14:20', messages: [] },
    { id: 4, name: 'Анонім', avatar: '🌙', preview: 'Привіт!', time: 'Вчора', messages: [] }
  ]);

  const gifts = [
    ['🎁', 'Подарунок', 100],
    ['🌹', 'Троянда', 50],
    ['🧸', 'Ведмедик', 200],
    ['💎', 'Діамант', 500],
    ['🎂', 'Торт', 150],
    ['🚀', 'Ракета', 300]
  ];

  const colors = dark
    ? {
        bg: '#17212b',
        card: '#202f3d',
        input: '#263746',
        text: '#ffffff',
        muted: '#8996a3',
        border: '#34404c',
        accent: '#35a9ff',
        outgoing: '#245b83'
      }
    : {
        bg: '#f2f5f8',
        card: '#ffffff',
        input: '#e5ebf0',
        text: '#17212b',
        muted: '#687887',
        border: '#d7e0e7',
        accent: '#1689df',
        outgoing: '#d5ebff'
      };

  const s = StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.bg },
    header: {
      height: 65, flexDirection: 'row',
      alignItems: 'center', justifyContent: 'space-between',
      paddingHorizontal: 18
    },
    logo: { color: colors.text, fontSize: 23, fontWeight: 'bold' },
    back: { color: colors.accent, fontSize: 17 },
    title: { color: colors.text, fontSize: 20, fontWeight: 'bold' },
    search: {
      backgroundColor: colors.input, color: colors.text,
      margin: 12, padding: 14, borderRadius: 12, fontSize: 16
    },
    section: { color: colors.muted, margin: 16 },
    chat: {
      flexDirection: 'row', alignItems: 'center',
      padding: 13, borderBottomWidth: 0.5,
      borderColor: colors.border
    },
    avatar: {
      fontSize: 32, marginRight: 14, width: 53,
      height: 53, textAlign: 'center',
      textAlignVertical: 'center',
      backgroundColor: colors.input, borderRadius: 30
    },
    name: { color: colors.text, fontSize: 16, fontWeight: '600' },
    message: { color: colors.muted, fontSize: 14, marginTop: 5 },
    time: { color: colors.muted, fontSize: 12 },
    navigation: {
      flexDirection: 'row', backgroundColor: colors.card,
      paddingVertical: 10, justifyContent: 'space-around',
      borderTopWidth: 1, borderColor: colors.border
    },
    tab: { alignItems: 'center', flex: 1 },
    tabIcon: { fontSize: 20 },
    tabText: { color: colors.muted, fontSize: 9, marginTop: 4 },
    active: { color: colors.accent, fontWeight: 'bold' },
    balance: {
      color: '#e9b93e', fontSize: 23,
      fontWeight: 'bold', textAlign: 'center', margin: 22
    },
    gifts: { flexDirection: 'row', flexWrap: 'wrap', padding: 7 },
    gift: {
      width: '46%', margin: '2%',
      backgroundColor: colors.card, borderRadius: 15,
      padding: 15, alignItems: 'center'
    },
    giftIcon: { fontSize: 42, marginBottom: 12 },
    price: { color: '#e9b93e', marginTop: 8 },
    button: {
      backgroundColor: colors.accent, padding: 11,
      borderRadius: 10, marginTop: 10
    },
    buttonText: { color: '#ffffff', fontWeight: 'bold' },
    setting: {
      padding: 19, flexDirection: 'row',
      justifyContent: 'space-between',
      borderBottomWidth: 0.5, borderColor: colors.border
    },
    settingText: { color: colors.text, fontSize: 15 },
    profile: { alignItems: 'center', padding: 20 },
    bigAvatar: { fontSize: 75, margin: 20 },
    profileCard: {
      width: '100%', backgroundColor: colors.card,
      padding: 18, borderRadius: 15, marginTop: 30
    },
    line: { height: 1, backgroundColor: colors.border, marginVertical: 15 },
    bubble: {
      padding: 12, borderRadius: 14,
      marginVertical: 5, maxWidth: '82%'
    },
    inputRow: {
      flexDirection: 'row', padding: 10,
      borderTopWidth: 1, borderColor: colors.border,
      alignItems: 'center'
    },
    chatInput: {
      flex: 1, backgroundColor: colors.input,
      color: colors.text, padding: 12, borderRadius: 20
    },
    send: {
      backgroundColor: colors.accent, padding: 13,
      borderRadius: 25, marginLeft: 8
    }
  });

  function sendMessage() {
    if (!draft.trim() || !selectedChat) return;

    const message = {
      id: Date.now(),
      text: draft.trim(),
      time: new Date().toLocaleTimeString('uk-UA', {
        hour: '2-digit',
        minute: '2-digit'
      })
    };

    setChats(old => old.map(chat =>
      chat.id === selectedChat.id
        ? {
            ...chat,
            messages: [...chat.messages, message],
            preview: message.text,
            time: message.time
          }
        : chat
    ));

    setSelectedChat(old => ({
      ...old,
      messages: [...old.messages, message]
    }));

    setDraft('');
  }

  function buyGift(gift) {
    if (balance < gift[2]) {
      alert('Недостатньо зірочок!');
      return;
    }

    setBalance(old => old - gift[2]);
    alert('Подарунок ' + gift[1] + ' придбано! 🎁');
  }

  function openChat(chat) {
    setSelectedChat(chat);
    setDraft('');
  }

  function backToChats() {
    setSelectedChat(null);
    setPage('Чати');
  }

  return (
    <View style={s.container}>
      <StatusBar
        barStyle={dark ? 'light-content' : 'dark-content'}
        backgroundColor={colors.bg}
      />

      <View style={s.header}>
        {selectedChat ? (
          <>
            <TouchableOpacity onPress={backToChats}>
              <Text style={s.back}>‹ Назад</Text>
            </TouchableOpacity>
            <Text style={s.title}>{selectedChat.name}</Text>
            <Text style={{ color: colors.muted }}>●</Text>
          </>
        ) : (
          <>
            <Text style={s.logo}>
              {page === 'Чати' ? 'OVERGRAM' : page}
            </Text>
            <Text style={{ color: colors.muted, fontSize: 25 }}>⋮</Text>
          </>
        )}
      </View>

      {selectedChat ? (
        <>
          <ScrollView
            style={{ flex: 1, padding: 12 }}
            contentContainerStyle={{ paddingBottom: 15 }}
          >
            <Text style={[s.section, { textAlign: 'center' }]}>
              Історія повідомлень
            </Text>

            {selectedChat.messages.map(message => (
              <View
                key={message.id}
                style={[
                  s.bubble,
                  {
                    alignSelf: 'flex-end',
                    backgroundColor: colors.outgoing
                  }
                ]}
              >
                <Text style={{ color: colors.text, fontSize: 16 }}>
                  {message.text}
                </Text>
                <Text style={{
                  color: colors.muted,
                  fontSize: 10,
                  textAlign: 'right',
                  marginTop: 5
                }}>
                  {message.time}
                </Text>
              </View>
            ))}
          </ScrollView>

          <View style={s.inputRow}>
            <TextInput
              style={s.chatInput}
              placeholder="Написати повідомлення..."
              placeholderTextColor={colors.muted}
              value={draft}
              onChangeText={setDraft}
              onSubmitEditing={sendMessage}
              returnKeyType="send"
            />
            <TouchableOpacity style={s.send} onPress={sendMessage}>
              <Text style={{ color: 'white', fontWeight: 'bold' }}>➤</Text>
            </TouchableOpacity>
          </View>
        </>
      ) : (
        <>
          {page === 'Чати' && (
            <>
              <TextInput
                style={s.search}
                placeholder="⌕  Пошук чатів"
                placeholderTextColor={colors.muted}
                value={search}
                onChangeText={setSearch}
              />
              <ScrollView>
                <Text style={s.section}>Усі повідомлення</Text>
                {chats.filter(c =>
                  c.name.toLowerCase().includes(search.toLowerCase())
                ).map(chat => (
                  <TouchableOpacity
                    key={chat.id}
                    style={s.chat}
                    onPress={() => openChat(chat)}
                  >
                    <Text style={s.avatar}>{chat.avatar}</Text>
                    <View style={{ flex: 1 }}>
                      <Text style={s.name}>{chat.name}</Text>
                      <Text style={s.message}>{chat.preview}</Text>
                    </View>
                    <Text style={s.time}>{chat.time}</Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>
            </>
          )}

          {page === 'Контакти' && (
            <ScrollView>
              <TextInput
                style={s.search}
                placeholder="Пошук користувачів"
                placeholderTextColor={colors.muted}
              />
              {chats.map(chat => (
                <TouchableOpacity
                  key={chat.id}
                  style={s.chat}
                  onPress={() => openChat(chat)}
                >
                  <Text style={s.avatar}>{chat.avatar}</Text>
                  <Text style={s.name}>{chat.name}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          )}

          {page === 'Подарунки' && (
            <ScrollView>
              <Text style={s.balance}>⭐ {balance} зірочок</Text>
              <Text style={s.section}>Магазин подарунків</Text>
              <View style={s.gifts}>
                {gifts.map((gift, i) => (
                  <View key={i} style={s.gift}>
                    <Text style={s.giftIcon}>{gift[0]}</Text>
                    <Text style={s.name}>{gift[1]}</Text>
                    <Text style={s.price}>{gift[2]} ⭐</Text>
                    <TouchableOpacity
                      style={s.button}
                      onPress={() => buyGift(gift)}
                    >
                      <Text style={s.buttonText}>Придбати</Text>
                    </TouchableOpacity>
                  </View>
                ))}
              </View>
            </ScrollView>
          )}

          {page === 'Налаштування' && (
            <ScrollView>
              <TouchableOpacity
                style={s.setting}
                onPress={() => setDark(!dark)}
              >
                <Text style={s.settingText}>🎨 Тема оформлення</Text>
                <Text style={{ color: colors.accent }}>
                  {dark ? 'Темна' : 'Світла'}
                </Text>
              </TouchableOpacity>

              {['Акаунт', 'Налаштування чатів',
                'Приватність і безпека', 'Сповіщення',
                'Дані та сховище', 'Мова',
                'Про OVERGRAM'].map((item, i) => (
                <View key={i} style={s.setting}>
                  <Text style={s.settingText}>{item}</Text>
                  <Text style={{ color: colors.muted }}>›</Text>
                </View>
              ))}
            </ScrollView>
          )}

          {page === 'Профіль' && (
            <ScrollView>
              <View style={s.profile}>
                <Text style={s.bigAvatar}>👤</Text>
                <Text style={[s.title, { fontSize: 23 }]}>
                  Overgram User
                </Text>
                <Text style={s.message}>@overgram_user</Text>
                <View style={s.profileCard}>
                  <Text style={s.name}>Ім'я користувача</Text>
                  <Text style={s.message}>Overgram User</Text>
                  <View style={s.line} />
                  <Text style={s.name}>Мій номер</Text>
                  <Text style={s.message}>OG-000001</Text>
                  <View style={s.line} />
                  <Text style={s.name}>Про себе</Text>
                  <Text style={s.message}>
                    Я користуюся OVERGRAM ⭐
                  </Text>
                </View>
              </View>
            </ScrollView>
          )}

          <View style={s.navigation}>
            {[
              ['Чати', '💬'],
              ['Контакти', '👥'],
              ['Подарунки', '⭐'],
              ['Налаштування', '⚙️'],
              ['Профіль', '👤']
            ].map(([name, icon]) => (
              <TouchableOpacity
                key={name}
                style={s.tab}
                onPress={() => {
                  setPage(name);
                  setSearch('');
                }}
              >
                <Text style={[
                  s.tabIcon,
                  page === name && s.active
                ]}>{icon}</Text>
                <Text style={[
                  s.tabText,
                  page === name && s.active
                ]}>{name}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </>
      )}
    </View>
  );
}
